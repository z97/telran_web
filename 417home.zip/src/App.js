import React from 'react';
import './App.css';
import Balance from "./components/Avatar";
import Operation from "./components/Operation";
import Body from "./components/Body";
import Nav from "./components/Nav"

const App = () => {
    return (
        <div className='App'>
            <Nav/>
            <Body/>
        </div>
    );
};

export default App;