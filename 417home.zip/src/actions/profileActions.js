export const DEPOSIT = 'DEPOSIT';

export const depositAction = sum => ({
    type: DEPOSIT,
    payload: sum
})
