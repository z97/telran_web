// state = {
//     balance: number
// }

import {DEPOSIT} from "../actions/profileActions";

export const accountReducer = (state, action) => {
    switch (action.type) {
        case DEPOSIT:
            return {...state, balance: action.payload};
        default:
            return state;
    }
}