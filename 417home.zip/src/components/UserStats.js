import React from 'react';
import Avatar from "./Avatar";
import {store} from "../configureStore/store";
const UserStats = () => {
    return (
                <div className='user-stats'>
                    <div>
                        <Avatar/>
                        {store.getState().user.name}
                    </div>
                    <div className='stats'>
                        <div>Followers: {store.getState().stats.followers}</div>
                        <div>Following: {store.getState().stats.following}</div>
                    </div>
                </div>
            )}

export default UserStats;