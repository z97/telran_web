import React, {Component} from 'react';
import {depositAction} from "../actions/profileActions";
import {connect} from "react-redux";

class Content extends Component {
    constructor(props) {
        super(props);
        this.state = {
            sum: ''
        }
    }

    render() {
        return (
            <div className='container'>
                <div className='row'>
                    <div className='mx-auto'>
                        <input
                            className='form-control-lg'
                            onChange={e => this.setState({sum: e.target.value})}
                            type='text'
                            min='0'
                            value={this.state.sum}
                        />
                        <button
                            className='btn btn-primary btn-lg'
                            onClick={() => this.props.deposit(this.state.sum)}
                        >Get Avatar</button>
                    </div>
                </div>
            </div>
        );
    }
}

const mapDispatchToProps = dispatch => (
    {
        deposit: sum => dispatch(depositAction(sum))
    }
)

export default connect(null, mapDispatchToProps)(Content);