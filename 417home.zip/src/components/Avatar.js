import React from 'react';
import {connect} from "react-redux";
import {store} from "../configureStore/store";
class Avatar extends React.Component {

    render() {
        return (
            <div>
                <img alt={'avatar'} src={store.getState().user.avatar}/>
                <h1 className='text-center text-uppercase'>Enter url of avatar:</h1>
            </div>
        );
    }
}

const mapStateToProps = state => (
    {
        amount: state.balance
    }
)

export default connect(mapStateToProps)(Avatar);