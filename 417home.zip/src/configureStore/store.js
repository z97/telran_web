import {accountReducer} from "../reducers/accountReducer";
import {createStore} from "redux";

export const initialState = {
    user: {
        avatar: 'https://www.gravatar.com/avatar/0?d=monsterid',
        name: 'Monster'
    },
    stats: {
        followers: 100,
        following: 10
    }
}
export const store = createStore(accountReducer, initialState);