import {result} from "../utils/constants";
import React, {Component} from 'react';

class Game extends Component {
    constructor(props) {
        super(props);
        this.state = {
            computerCard: [2,4],
            myCard: [3,5],
            i: 0
        }
    }

    checkDeck = () => {
        var i = this.state.i;
        if (this.state.i < 26){
            this.setState({i: i + 1});
            this.render(Game)
        }
        else{
            this.props.changePage(result)
        }
    }

    render() {
        return (
            <div>
                <h1>Computer</h1>
                <p>Computer card: {this.state.computerCard[this.state.i]}</p>
                <p>Player card: {this.state.myCard[this.state.i]}</p>
                <h1>{this.props.name}</h1>
                <button onClick={() => this.checkDeck()}>Next</button>
            </div>
        );
    }
}

export default Game;