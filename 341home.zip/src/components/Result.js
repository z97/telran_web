import React from 'react';
import {game} from "../utils/constants";

const Result = (props) => {
    return (
        <div>
            <h1>Lose\Win</h1>
            <h3>1-0</h3>
            <button onClick={() => props.changePage(game)}>Again?</button>
        </div>
    );
};

export default Result;