import React from "react";
import Start from "./components/Start";
import Game from "./components/Game";
import Result from "./components/Result";
import {game, result, start} from "./utils/constants";

class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            page: start,
            name: ''
        }
    }

    changeName = text => {
        this.setState({name: text});
    }

    changePage = page => {
        this.setState({page});
    }

    render() {
        switch (this.state.page) {
            case game:
                return <Game name={this.state.name} changePage={this.changePage}/>;
            case result:
                return <Result changePage={this.changePage}/>;
            default:
                return <Start changeName={this.changeName} changePage={this.changePage}/>
        }
    }


}

export default App;
