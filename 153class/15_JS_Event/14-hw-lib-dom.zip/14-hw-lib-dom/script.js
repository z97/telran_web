const root = document.getElementById('root');
const library = [];
//isbn;title;author;year
let inputData = prompt('Enter book data separate by ";"');
while (inputData) {
    const arr = inputData.split(';');
    const book = new Book(arr[0], arr[1], arr[2], arr[3]);
    if (findBook(library, book) < 0) {
        library.push(book);
    } else {
        alert(`Book with isbn=${book.isbn}, exists`);
    }

    inputData = prompt('Enter book data separate by ";"');
}

const choice = confirm('Do you want show the books info');
if (choice) {
    //TODO display on page all books, age of oldest and newest books, average age of books
    for(let i = 0; i < library.length; i++){
        root.appendChild(createInfoElement(library[i].toString()));
    }
    root.appendChild(createInfoElement(`age of oldest book: ${getOldestBook(library).getBookAge()}`));
    root.appendChild(createInfoElement(`age of newest book: ${getNewestBook(library).getBookAge()}`));
    root.appendChild(createInfoElement(`average age of books: ${getAvgBookAge(library).toFixed(1)}`));
} else {
    const isbn = prompt('Enter isbn');
    //TODO display on page book with current isbn
    const book = findBookByIsbn(library, isbn);
    root.appendChild(createInfoElement(book || `library not include book with isbn = ${isbn}`));
}

function createInfoElement(content) {
    const element = document.createElement('p');
    const text = document.createTextNode(content);
    element.appendChild(text);
    return element;
}

function findBook(library, book) {
    for (let i = 0; i < library.length; i++) {
        if (library[i].isbn === book.isbn) {
            return i;
        }
    }
    return -1;
}

function findBookByIsbn(library, isbn) {
    for (let i = 0; i < library.length; i++) {
        if (library[i].isbn === isbn) {
            return library[i];
        }
    }
    return null;
}

function getOldestBook(library) {
    let index = 0;
    for (let i = 0; i < library.length; i++) {
        if (library[index].year > library[i].year) {
            index = i;
        }
    }
    return library[index];
}

function getNewestBook(library) {
    let index = 0;
    for (let i = 0; i < library.length; i++) {
        if (library[index].year < library[i].year) {
            index = i;
        }
    }
    return library[index];
}

function getAvgBookAge(library) {
    let sum = 0;
    for (let i = 0; i < library.length; i++) {
        sum += library[i].getBookAge();
    }
    return sum / library.length;
}

function printArray(arr) {
    for (let i = 0; i < arr.length; i++) {
        console.log(arr[i].toString());
    }
}

function Book(isbn, title, author, year) {
    this.isbn = isbn;
    this.title = title;
    this.author = author;
    this.year = +year;
    this.toString = function () {
        return `ISBN: ${this.isbn}, Title: ${this.title},
         Author: ${this.author}, Year of publishing: ${this.year}`
    }
    this.getBookAge = function () {
        const d = new Date();
        return d.getFullYear() - this.year;
    }
}

//1;Book1;Author1;1998
//2;Book2;Author2;1990
//3;Book3;Author1;2010
