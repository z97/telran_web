//const button = document.getElementById('button');
const input = document.getElementById('name');
//const other = document.getElementById('other');
button.onclick = show;
input.onkeyup = changeText;
other.onkeyup = changeText;

function show(event) {
    console.log(event.target);
   alert(`${input.value}`);
}

function changeText(event) {
    //console.log(event.target);
    event.target.value = event.target.value.toUpperCase();
}
