console.log('===solution 3===');
for (var i = 0; i < 10; i++) {
    setTimeout(function () {
    }, 1000);
    console.log(i);
}
