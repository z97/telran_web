console.log('===solution 4===');
for (var i = 0; i < 10; i++) {
    function a (b) {
        setTimeout(function () {
            console.log(b);
        }, 1000);
    }
}

for (let j = 0; j < 10; j++){
    window.a(i);
}