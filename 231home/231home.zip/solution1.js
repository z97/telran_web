//============ Solution 1 ============
console.log('===solution 1===')
for (var i2 = 1; i2 < 10; i2++) {
    for (var j = 1; j > 0; j--) {
        a = setTimeout(function () {
        }, 1000);
    }
    console.log(a);
}