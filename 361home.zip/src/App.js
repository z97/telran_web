import React from "react";
import './App.css';
import Header from "./components/Header";
import Main from "./components/Main";
import Footer from "./components/Footer";
import {homePage} from "./utils/constants";

class App extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            page: homePage
        }
    }

    changePage = page => {
        this.setState({page})
    }

    render() {
        return (
            <div className='container-fluid'>
                <Header changePage={this.changePage}/>
                <Main page={this.state.page}/>
                <Footer/>
            </div>
        );
    }
}

export default App;
