import React from 'react';
import hero from "../Images/main.jpg";

const Hero = () => {
    return (
        <section className="float-left w-25 mr-1">
            <img src={hero} alt="Luke Skywalker"/>
        </section>
    );
};

export default Hero;