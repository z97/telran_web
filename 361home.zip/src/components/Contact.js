import React, {Component} from 'react';
import {base_url, month} from "../utils/constants";

class Contact extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: true
        };
    }



    componentDidMount() {
        var timestampContacts = new Date().getTime()
        const text = localStorage.getItem('data');

        function checkTime() {
            return ((timestampContacts - localStorage.getItem('timestamp')) > month);
        }



        if (text && !checkTime()) {
            this.setState({
                isLoading: false,
                data: text
            })
        } else {
            localStorage.clear();
            fetch(`${base_url}/v1/planets`)
                .then(response => response.json())
                .then(data => {
                    this.setState({
                        isLoading: false,
                        data: [data]
                    });
                    localStorage.setItem('data', [data]);
                    localStorage.setItem('timestamp', JSON.stringify(timestampContacts))
                })
        }
    }

    render() {

        const text = this.state.isLoading ? 'Loading...' : this.state.data;
        return (
            <div className="container">
                <label htmlFor="fname">First Name</label>
                <input type="text" id="fname" name="firstname" placeholder="Your name.."/>

                <label htmlFor="lname">Last Name</label>
                <input type="text" id="lname" name="lastname" placeholder="Your last name.."/>

                <label htmlFor="country">{text}</label>
                <select id="country" name="country">
                    <option value="australia">{text}</option>
                </select>

                <label htmlFor="subject">Subject</label>
                <textarea id="subject" name="subject" placeholder="Write something.."/>

                <input type="submit" value="Submit"/>
            </div>
        );
    }
}

export default Contact;