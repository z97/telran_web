import React from 'react';
import {aboutMePage, contactPage, homePage, starWarsPage} from "../utils/constants";

const Navigation = ({changePage}) => {
    return (
        <nav className="fixed-top mt-2 ml-4">
            <ul className="nav">
                <li onClick={() => changePage(homePage)} className="nav-item btn btn-danger mx-1">Home</li>
                <li onClick={() => changePage(aboutMePage)} className="nav-item btn btn-danger mx-1">About Me</li>
                <li onClick={() => changePage(starWarsPage)} className="nav-item btn btn-danger mx-1">Star Wars</li>
                <li onClick={() => changePage(contactPage)} className="nav-item btn btn-danger mx-1">Contact</li>
            </ul>
        </nav>
    );
};

export default Navigation;