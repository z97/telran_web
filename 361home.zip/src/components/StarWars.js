import React from 'react';

const StarWars = () => {
    return (
        <div>
            Star Wars
        </div>
    );
};

export default StarWars;