import React, {Component} from 'react';
import {base_url, month} from "../utils/constants";

class AboutMe extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: true
        };
    }

    componentDidMount() {
        var timestamp = new Date().getTime()
        const text = localStorage.getItem('luke_skywalker');
        function checkTime(){
            return ((timestamp - localStorage.getItem('timestamp')) > month);
        }
        if (text && !checkTime()) {
            this.setState({
                isLoading: false,
                luke_skywalker: text
            })
        } else {
            localStorage.clear();
            fetch(`${base_url}/v1/peoples/1`)
                .then(response => response.json())
                .then(data => {
                    this.setState({
                        isLoading: false,
                        luke_skywalker:
                            ['name: ', data.name,
                            'gender: ', data.gender,
                            'hair_color: ', data.hair_color,
                            'mass: ', data.mass],
                    });
                    localStorage.setItem('luke_skywalker', [
                            'name: ', data.name,
                            'gender: ', data.gender,
                            'hair_color: ', data.hair_color,
                            'mass: ', data.mass
                        ],
                    );
                    localStorage.setItem('timestamp', JSON.stringify(timestamp))
                });
        }
    }

    render() {
        const text = this.state.isLoading ? 'Loading...' : this.state.luke_skywalker;
        return (
            <p className={`text-justify`}>{text}</p>
        );
    }
}

export default AboutMe;