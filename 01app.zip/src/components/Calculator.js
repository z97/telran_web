import React, {Component} from 'react';

class Calculator extends Component {
    constructor(props) {
        super(props);
        this.state = {
            a: '',
            b: '',
            res: 0
        }
    }
    calculator = (a, b) => {
        return (a ** b);
    }

    getResult = () => {
        this.setState({res: this.calculator(this.state.a, this.state.b)})
    }

    render() {
        return (
            <div>
                <h1>Calulator</h1>
                <input
                    onChange={(e) => this.setState({
                        a: e.target.value.trim()
                    })}
                    value={this.state.a}
                    type='text'
                    placeholder='Enter a:'/>
                <input
                    onChange={(e) => this.setState(
                        {b: e.target.value.trim()})}
                    value={this.state.b}
                    type='text'
                    placeholder='Enter b:'/>
                <button onClick={this.getResult}>Get Result</button>
                <h1>{this.state.res}</h1>
            </div>
        );
    }
}

export default Calculator;