export const ADD_FOLLOWER = 'ADD_FOLLOWER'
export const ADD_FOLLOWING = 'ADD_FOLLOWING'
export const REMOVE_FOLLOWING = 'REMOVE_FOLLOWING'

export const addFollowerAction = num => (
    {
        type: ADD_FOLLOWER,
        payload: num
    }
)

export const addFollowingAction = num => (
    {
        type: ADD_FOLLOWING,
        payload: num
    }
)

export const removeFollowingAction = num => (
    {
        type: REMOVE_FOLLOWING,
        payload: num
    }
)
