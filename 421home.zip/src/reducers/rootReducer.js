import { combineReducers } from 'redux'
import statReducer from './statReducer'
import avatarReducer from './avatarReducer'

export const rootReducer= combineReducers({
    avatarReducer: avatarReducer,
    statReducer: statReducer

})

export default rootReducer
