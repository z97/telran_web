import {CHANGE_AVATAR, CHANGE_NAME} from "../actions/accountActions";
import {initialState} from "../configureStore/initialState";

export const avatarReducer = (state = initialState, action) => {
    let user;
    switch (action.type) {
        case CHANGE_AVATAR:
            user = {...state.user, avatar: action.payload || state.user.avatar}
            return {...state, user};
        case CHANGE_NAME:
            user = {...state.user, name: action.payload || state.user.name}
            return {...state, user};
        default:
            return state;
    }
}

export default avatarReducer