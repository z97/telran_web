import {ADD_FOLLOWING, ADD_FOLLOWER} from "../actions/statsActions";
import {initialState} from "../configureStore/initialState";

export const statReducer = (state = initialState, action) => {
    let stats;
    switch (action.type) {
        case ADD_FOLLOWER:
            stats = {...state.stats, followers: action.payload || state.stats.followers}
            return {...state, stats}
        case ADD_FOLLOWING:
            stats = {...state.stats, following: action.payload || state.stats.following}
            return {...state, stats}
        default:
            return state;
    }
}

export default statReducer