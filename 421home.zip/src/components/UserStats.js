import React from 'react';
import Avatar from "./Avatar";
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import {addFollowerAction, addFollowingAction} from "../actions/statsActions";

const UserStats = (props, {name, followers, following}) => {
    return (
        <div className='user-stats'>
            <div>
                <Avatar/>
                {name}
            </div>
            <div className='stats'>
                <div
                    onClick={() => {props.addFollower(props.followers + 1)}}
                     onContextMenu={(e) => {
                         e.preventDefault();
                         props.addFollower(props.followers > 0 ? props.followers - 1 : props.followers)}
                     }>
                    Followers: {props.followers}
                </div>
                <div
                    onClick={() => {props.addFollowing(props.following + 1)}}
                     onContextMenu={(e) => {
                         e.preventDefault();
                         props.addFollowing(props.following > 0 ? props.following - 1 : props.following)}
                     }>
                    Following: {props.following}
                </div>
            </div>
        </div>
    )
}

const mapStateToProps = state => (
    {
        name: state.user.name,
        followers: state.stats.followers,
        following: state.stats.following
    }
)

const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        addFollower: addFollowerAction,
        addFollowing: addFollowingAction,
    }, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(UserStats);