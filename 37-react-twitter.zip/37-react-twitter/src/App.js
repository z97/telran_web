import React from "react";
import Nav from "./components/Nav";
import Body from "./components/Body";
import {UserContext} from "./context/userContext";

class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            user: {
                avatar: 'https://www.gravatar.com/avatar/0?d=monsterid',
                name: 'Monster'
            },
            stats: {
                followers: 100,
                following: 10
            }
        }
    }

    changeAvatar = url => {
        const user = {...this.state.user};
        user.avatar = url || user.avatar;
        this.setState({user});
    }

    render() {
        return (
            <div className='app'>
                <UserContext.Provider value={
                    {
                        user: this.state.user,
                        stats: this.state.stats,
                        changeAvatar: this.changeAvatar
                    }
                }>
                    <Nav/>
                    <Body/>
                </UserContext.Provider>
            </div>
        );
    }
}

export default App;
