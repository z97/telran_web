import React from 'react';
import Avatar from "./Avatar";
import {UserContext} from "../context/userContext";

const UserStats = () => {
    return (
        <UserContext.Consumer>
            {value => (
                <div className='user-stats'>
                    <div>
                        <Avatar/>
                        {value.user.name}
                    </div>
                    <div className='stats'>
                        <div>Followers: {value.stats.followers}</div>
                        <div>Following: {value.stats.following}</div>
                    </div>
                </div>
            )}
        </UserContext.Consumer>
    );
};

export default UserStats;