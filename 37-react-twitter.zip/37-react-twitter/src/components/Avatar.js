import React from 'react';
import {UserContext} from "../context/userContext";

const Avatar = (props) => {
    return (
        <UserContext.Consumer>
            {value => (
                <img
                    className={`user-avatar ${props.size || ''}`}
                    src={value.user.avatar}
                    alt={value.user.name}
                    onClick={() => {
                        const url = prompt("Enter your avatar url");
                        value.changeAvatar(url);
                    }}
                />
            )}
        </UserContext.Consumer>
    );
}

export default Avatar;