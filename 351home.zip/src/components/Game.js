import React from 'react';
import {result} from "../utils/constants";

class Game extends React.Component {
    constructor(props) {
        super(props);
        this.compDeck = [{number: 2, suit: 'spade'}, {number: 5, suit: 'diamond'}];
        this.playerDeck = [{number: 3, suit: 'heart'}, {number: 8, suit: 'club'}];
        this.state = {
            compCard: 'Computer card',
            playerCard: 'Player card',
            compWins: 0,
            playerWins: 0
        }
    }

    handleClickNext = () => {
        if (this.compDeck.length) {
            const comp = this.compDeck.pop();
            const player = this.playerDeck.pop();
            if (comp.number > player.number) {
                this.setState((prevState, props) => ({compWins: prevState.compWins + 1}));
            }
            if (comp.number < player.number) {
                this.setState((prevState, props) => ({playerWins: prevState.playerWins + 1}));
            }
            this.setState({
                compCard: `${comp.number}, ${comp.suit}`,
                playerCard: `${player.number}, ${player.suit}`
            });
        } else {
            this.props.getCompWins(this.state.compWins);
            this.props.getPlayerWins(this.state.playerWins);
            this.props.changePage(result);
        }

    }

    render() {
        return (
            <div>
                <h1>Computer {`(${this.state.compWins})`}</h1>
                <p>{this.state.compCard}</p>
                <p>{this.state.playerCard}</p>
                <h1>{this.props.name} {`(${this.state.playerWins})`}</h1>
                <button onClick={this.handleClickNext}>Next</button>
            </div>
        );
    }
}

export default Game;