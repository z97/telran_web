import {game} from "../utils/constants";
import React, {Component} from 'react';


class Result extends Component {
    constructor(props) {
        super(props);
        this.state = {
            allCompWins: 0,
            allPlayerWins: 0,
        }
    }

    addWinToAllGamesWin = () => {
        if (this.props.playerWins > this.props.compWins) {
            this.setState((prevState, props) => ({allCompWins: prevState.allCompWins + 1}));
        }
        if (this.props.playerWins < this.props.compWins) {
            this.setState((prevState, props) => ({allPlayerWins: prevState.allPlayerWins + 1}));
        }
    }
    printScore = () => {
        return (<h3>{`(Computer wins: ${this.state.allCompWins} ${this.props.name} wins: ${this.state.allPlayerWins})`}</h3>)
    }

    printButton = () => {
        return (<button onClick={() => this.props.changePage(game)}>Again?</button>)
    }

    render() {
        return (
            <div>
                {this.addWinToAllGamesWin()}
                {this.printScore()}
                {this.printButton()}
            </div>
        );
    }
}

export default Result;