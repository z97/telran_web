export const start = 'start';
export const game = 'game';
export const result = 'result';