import React from "react";
import Start from "./components/Start";
import Game from "./components/Game";
import Result from "./components/Result";
import {game, result, start} from "./utils/constants";

class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            page: start,
            name: '',
            compWins: 0,
            playerWins: 0
        }
    }

    getCompWins = compWins => {
        this.setState({compWins: compWins});
    }

    getPalayerWins = playerWins => {
        this.setState({playerWins: playerWins});
    }

    changeName = text => {
        this.setState({name: text});
    }

    changePage = page => {
        this.setState({page});
    }

    render() {
        switch (this.state.page) {
            case game:
                return <Game name={this.state.name}
                             changePage={this.changePage}
                             getCompWins={this.getCompWins}
                             getPlayerWins={this.getPalayerWins}/>;
            case result:
                return <Result name={this.state.name}
                               changePage={this.changePage}
                               compWins={this.state.compWins}
                               playerWins={this.state.playerWins}/>;
            default:
                return <Start changeName={this.changeName} changePage={this.changePage}/>
        }
    }


}

export default App;
