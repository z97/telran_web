import React from 'react';
import Form from "./Form";
import Weather from "./Weather";
import {base_url, api_key} from "../utils/constants";

class Data extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            message: 'Enter city name'
        }
    }

    getWeather = city => {
        fetch(`${base_url}?q=${city}&appid=${api_key}&units=metric`)
            .then(response => response.json())
            .then(data => this.setState({
                weatherInfo: {
                    country: data.sys.country,
                    city: data.name,
                    temp: data.main.temp,
                    pressure: data.main.pressure,
                    sunset: data.sys.sunset
                },
                message: null
            }))
            .catch(e => {
                console.log(e);
                this.setState({message: 'Enter correct city name', weatherInfo: null});
            });
    }

    render() {
        return (
            <div>
                <Form getWeather={this.getWeather}/>
                <Weather weather={this.state.weatherInfo} message={this.state.message}/>
            </div>
        );
    }
}

export default Data;