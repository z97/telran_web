export const WEATHER = 'WEATHER';

export const putWeatherAction = city => (
    {
        type: WEATHER,
        payload: city
    }
)