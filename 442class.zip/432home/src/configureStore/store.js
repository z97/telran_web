

import {weatherReducer} from '../reducers/weatherReducer';
import {applyMiddleware, createStore} from "redux";
import {logger} from "redux-logger";

export const initialState = {
    message: 'Enter city name'
}

export const store = createStore(weatherReducer, initialState, applyMiddleware(logger))