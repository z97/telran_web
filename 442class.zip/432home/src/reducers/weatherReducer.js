import {WEATHER} from '../actions/weatherActions';

export const weatherReducer = (state, action) => {
    switch (action.type){
        case WEATHER:
            return {...state, weatherInfo: action.payload};
        default:
            return state;
    }
}