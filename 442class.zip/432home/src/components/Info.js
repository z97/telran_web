import React from "react";
const Info = () => {
    return (
        <div>
            <h2>Weather application</h2>
            <p>Your city weather</p>
        </div>
    )
}

export default Info;