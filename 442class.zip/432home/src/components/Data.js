import {putWeatherAction} from "../actions/weatherActions";
import {connect} from "react-redux";
import {base_url} from "../utils/constants";
import {api_key} from "../utils/constants";
import React, {Component} from 'react';
import {store} from "../configureStore/store";
import Weather from "./Weather";

class Data extends Component {
    constructor(props) {
        super(props);
        this.state = {
            message: null,
            city: ''
        }
    }

    handleGetCitySubmit = e => {
        e.preventDefault();
        const city = e.currentTarget.city.value.trim();
        this.getWeather(city);

    }

    getWeather = city => {
        fetch(`${base_url}?q=${this.state.city}&appid=${api_key}&units=metric`)
            .then(response => response.json())
            .then(data => this.setState({
                weatherInfo: {
                    country: data.sys.country,
                    city: data.name,
                    temp: data.main.temp,
                    pressure: data.main.pressure,
                    sunset: data.sys.sunset
                },
                message: null
            }))
            .then(data => this.props.putWeather(this.state.weatherInfo))
            .catch(e => {
                console.log(e);
                this.setState({message: 'Enter correct city name', weatherInfo: ''});
            });
    }


    render() {
        return (
            <div>
                <form onSubmit={this.handleGetCitySubmit}>
                    <input type={'text'}
                           name={'city'}
                           onChange={e => this.setState({city: e.target.value})}/>
                    <button
                        type={'submit'}
                        className='btn btn-info btn-lg'

                    >Get Weather
                    </button>

                </form>
                <Weather/>
            </div>
        )
    }
}


const mapDispatchToProps = dispatch => (
    {
        putWeather: weather => dispatch(putWeatherAction(weather))
    }
)


export default connect(null, mapDispatchToProps)(Data)