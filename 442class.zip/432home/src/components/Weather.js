import React, {Component} from 'react';
import {connect} from "react-redux";

class Weather extends Component {
    render() {
        return (
            <div className='infoWeather'>
                {!this.props.message &&
                <div>
                    <p>Location: {this.props.weatherInfo.country}, {this.props.weatherInfo.city}</p>
                    <p>Temp: {this.props.weatherInfo.temp}</p>
                    <p>Pressure: {this.props.weatherInfo.pressure}</p>
                    <p>Sunset: {new Date(this.props.weatherInfo.sunset * 1000).toTimeString()}</p>
                </div>
                }
                <p>{this.props.message}</p>
            </div>
        );
    }
}

const mapStateToProps = props => (
    {
        message: props.message,
        weatherInfo: props.weatherInfo
    }
)

export default connect(mapStateToProps)(Weather);