import React from 'react';

const Error = () => {
    return (
        <h1>
           O-o-o-ps, page not found
        </h1>
    );
};

export default Error;