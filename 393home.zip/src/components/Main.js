import React from 'react';
import {Route, Switch} from 'react-router-dom';
import Home from "./Home";
import AboutMe from "./AboutMe";
import StarWars from "./StarWars";
import Contact from "./Contact";
import Error from "./Error";
import {aboutMePage, contactPage, defaultHero, friends, homePage, starWarsPage} from "../utils/constants";

const Main = ({changeHero, hero}) => {

    return (
        <Switch>
            <Route path={['/', `/${homePage}`, '/:hero', `/${homePage}/:hero`]} exact render={() => <Home hero={hero}/>}/>
            <Route path={[`/${aboutMePage}`, `/${aboutMePage}/:hero`]} exact render={({match}) => {
                const hero = match.params.hero ?? defaultHero;
                if (friends.includes(hero)) {
                    return <AboutMe hero={hero} changeHero={changeHero}/>;
                } else {
                    return <Error/>;
                }
            }}/>
            <Route path={`/${starWarsPage}`} exact><StarWars/></Route>
            <Route path={`/${contactPage}`} exact component={Contact}/>
            <Route component={Error}/>
        </Switch>
    )
}

export default Main;