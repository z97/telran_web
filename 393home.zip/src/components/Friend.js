import React from 'react';
import style from '../css_modules/friend.module.css';
import {characters} from "../utils/constants";

const Friend = ({friend, number}) => {
    let styles = "col-4 p-1 ";
    if (number === 7) {
        styles += style.bottomLeft;//"col-4 p-1 bottomLeft"
    }
    if (number === 9) {
        styles += style.bottomRight;
    }
    return (
        <img className={styles} src={characters[friend].img} alt={characters[friend].name}/>
    );
}

export default Friend;