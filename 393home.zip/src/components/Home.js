import React from 'react';
import Hero from "./Hero";
import DreamTeam from "./DreamTeam";
import FarGalaxy from "./FarGalaxy";

const Home = ({hero}) => {

    return (
        <main className="clearfix">
            <Hero hero={hero}/>
            <DreamTeam hero={hero}/>
            <FarGalaxy/>
        </main>
    );
};

export default Home;