import React from 'react';
import {characters} from "../utils/constants";

const Hero = ({hero}) => {
    return (
        <section className="float-left w-25 mr-1">
            <img src={characters[hero].img} alt={characters[hero].name}/>
        </section>
    );
};

export default Hero;