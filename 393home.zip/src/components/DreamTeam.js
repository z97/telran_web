import React from 'react';
import Friend from "./Friend";
import {friends} from "../utils/constants";

const DreamTeam = ({hero}) => {
    const team = friends.filter(item => item !== hero);
    return (
        <section className="float-right w-50 row no-gutters border">
            <h2 className="col-12 text-center">Dream Team</h2>
            {team.map((item, index) => <Friend key={index} number={index + 1} friend={item}/>)}
        </section>
    );
};

export default DreamTeam;