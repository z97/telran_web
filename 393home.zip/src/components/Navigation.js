import React from 'react';
import {aboutMePage, contactPage, homePage, starWarsPage} from "../utils/constants";
import {Link} from "react-router-dom";

const Navigation = ({hero}) => {
    return (
        <nav className="fixed-top mt-2 ml-4">
            <ul className="nav">
                <Link to={`/${homePage}`}><li className="nav-item btn btn-danger mx-1">Home</li></Link>
                <Link to={`/${aboutMePage}/${hero}`}><li className="nav-item btn btn-danger mx-1">About Me</li></Link>
                <Link to={`/${starWarsPage}`}><li className="nav-item btn btn-danger mx-1">Star Wars</li></Link>
                <Link to={`/${contactPage}`}><li className="nav-item btn btn-danger mx-1">Contact</li></Link>
            </ul>
        </nav>
    );
};

export default Navigation;