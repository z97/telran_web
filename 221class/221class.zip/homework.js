let group = {
    title: 'Java 41',
    students: ['Alla', 'Tanya', 'Viktoriya', 'Lubov', 'Mariya', 'Olya'],
    showList: function (){
        const show = function (name){
            console.log(`${this.title}: ${name}`);
        }
        this.students.forEach(show);
    }
}

group.showList();
const newGroup = group;
group = null;
console.log('================')
newGroup.showList();

//================Answer1================

let group2 = {
    title: 'Java 41',
    students: ['Alla', 'Tanya', 'Viktoriya', 'Lubov', 'Mariya', 'Olya'],
    showList (){
        const show = (name) => {
            console.log(`${this.title}: ${name}`);
        }
        this.students.forEach(show);
    }
}

group2.showList();
const newGroup2 = group2;
group2 = null;
console.log('================')
newGroup2.showList();

//==================Answer2=================

let group3 = {

    title: 'Java 41',
    students: ['Alla', 'Tanya', 'Viktoriya', 'Lubov', 'Mariya', 'Olya'],
    showList: function (){
        const show = function (name){
            console.log(`${this.title}: ${name}`);
        }.bind(this)
        this.students.forEach(show);
    }
};

group3.showList();
const newGroup3 = group3;
group3 = null;
console.log('================')
newGroup3.showList();

//==============Answer 3=============
let group4 = {

    title: 'Java 41',
    students: ['Alla', 'Tanya', 'Viktoriya', 'Lubov', 'Mariya', 'Olya'],
    showList: function (){
        let that = this;
        const show = function (name){
            console.log(`${that.title}: ${name}`);
        }
        this.students.forEach(show);
    }
}

group4.showList();
const newGroup4 = group4;
group4 = null;
console.log('================')
newGroup4.showList();